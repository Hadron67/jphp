package com.hadroncfy.jphp.jzend.compile1;

/**
 * Created by cfy on 16-5-10.
 */
public class CompilationException extends Exception{

}
